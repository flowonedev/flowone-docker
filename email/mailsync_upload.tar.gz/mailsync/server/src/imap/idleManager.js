/**
 * IMAP IDLE Manager
 * 
 * Manages persistent IMAP connections with IDLE support for real-time
 * new mail detection. One connection per active user.
 */

import Imap from 'node-imap'
import { config } from '../config.js'
import { EventTypes } from '../events/eventTypes.js'

export class ImapIdleManager {
  constructor(eventStore, clientManager, publishEventFn) {
    this.eventStore = eventStore
    this.clientManager = clientManager
    this.publishEvent = publishEventFn
    
    // Map of userEmail -> ImapConnection
    this.connections = new Map()
    
    // Track reconnection attempts
    this.reconnectAttempts = new Map()
    
    // IDLE refresh interval (RFC 2177 recommends < 29 minutes)
    this.idleRefreshInterval = config.imap.idleTimeout
  }

  /**
   * Start IDLE monitoring for a user
   * @param {string} userEmail 
   * @param {string} password - User's password or OAuth token
   * @param {string} folder - Folder to monitor (default: INBOX)
   * @param {object} options - Additional options (oauth, host override, etc.)
   */
  async startIdle(userEmail, password, folder = 'INBOX', options = {}) {
    // Check if already connected
    if (this.connections.has(userEmail)) {
      console.log(`[ImapIdle] Already monitoring ${userEmail}`)
      return
    }

    // Check connection limit
    if (this.connections.size >= config.performance.maxIdleConnections) {
      console.warn(`[ImapIdle] Max connections reached (${config.performance.maxIdleConnections})`)
      return
    }

    try {
      const connection = await this.createConnection(userEmail, password, folder, options)
      this.connections.set(userEmail, connection)
      this.reconnectAttempts.set(userEmail, 0)
      
      console.log(`[ImapIdle] Started monitoring ${folder} for ${userEmail}`)
    } catch (error) {
      console.error(`[ImapIdle] Failed to start IDLE for ${userEmail}:`, error.message)
      throw error
    }
  }

  /**
   * Create an IMAP connection with IDLE support
   */
  async createConnection(userEmail, password, folder, options) {
    return new Promise((resolve, reject) => {
      const imapConfig = {
        user: userEmail,
        password: password,
        host: options.host || config.imap.host,
        port: options.port || config.imap.port,
        tls: config.imap.tls,
        tlsOptions: config.imap.tlsOptions,
        // OAuth2 support
        ...(options.oauth && {
          xoauth2: options.oauth,
        }),
      }

      const imap = new Imap(imapConfig)
      
      // Connection state
      const state = {
        userEmail,
        folder,
        password,
        options,
        idleTimer: null,
        isReady: false,
      }

      // Handle ready
      imap.once('ready', () => {
        state.isReady = true
        console.log(`[ImapIdle] Connected for ${userEmail}`)
        
        // Open folder and start IDLE
        imap.openBox(folder, true, (err, box) => {
          if (err) {
            console.error(`[ImapIdle] Failed to open ${folder}:`, err)
            reject(err)
            return
          }

          state.box = box
          state.uidnext = box.uidnext
          
          // Start IDLE
          this.startIdleMode(imap, state)
          
          resolve({ imap, state })
        })
      })

      // Handle mail event (new messages)
      imap.on('mail', async (numNewMsgs) => {
        console.log(`[ImapIdle] ${numNewMsgs} new message(s) for ${userEmail}`)
        await this.handleNewMail(imap, state, numNewMsgs)
      })

      // Handle expunge (deleted messages)
      imap.on('expunge', async (seqno) => {
        console.log(`[ImapIdle] Message expunged (seq ${seqno}) for ${userEmail}`)
        await this.handleExpunge(state, seqno)
      })

      // Handle update (flags changed)
      imap.on('update', async (seqno, info) => {
        console.log(`[ImapIdle] Message updated (seq ${seqno}) for ${userEmail}`)
        await this.handleUpdate(state, seqno, info)
      })

      // Handle errors
      imap.on('error', (err) => {
        console.error(`[ImapIdle] Error for ${userEmail}:`, err.message)
        this.handleDisconnect(userEmail, err)
      })

      // Handle end/close
      imap.on('end', () => {
        console.log(`[ImapIdle] Connection ended for ${userEmail}`)
        this.handleDisconnect(userEmail)
      })

      imap.on('close', (hadError) => {
        console.log(`[ImapIdle] Connection closed for ${userEmail} (error: ${hadError})`)
        if (hadError) {
          this.handleDisconnect(userEmail, new Error('Connection closed with error'))
        }
      })

      // Connect
      imap.connect()
    })
  }

  /**
   * Start IDLE mode on an IMAP connection
   */
  startIdleMode(imap, state) {
    // Clear existing timer
    if (state.idleTimer) {
      clearTimeout(state.idleTimer)
    }

    // Enter IDLE mode (if supported)
    if (imap.serverSupports('IDLE')) {
      // Refresh IDLE periodically (RFC 2177)
      state.idleTimer = setTimeout(() => {
        if (state.isReady) {
          console.log(`[ImapIdle] Refreshing IDLE for ${state.userEmail}`)
          // NOOP breaks IDLE and re-enters it
          imap.noop(() => {
            this.startIdleMode(imap, state)
          })
        }
      }, this.idleRefreshInterval)
    } else {
      console.warn(`[ImapIdle] Server doesn't support IDLE for ${state.userEmail}, falling back to polling`)
      // Fallback: poll every 60 seconds
      state.idleTimer = setInterval(() => {
        if (state.isReady) {
          imap.noop(() => {})
        }
      }, 60000)
    }
  }

  /**
   * Handle new mail notification
   */
  async handleNewMail(imap, state, numNewMsgs) {
    try {
      // Fetch new message info
      const newUidnext = await this.getUidnext(imap, state.folder)
      
      if (newUidnext > state.uidnext) {
        // Fetch new messages
        const range = `${state.uidnext}:*`
        const messages = await this.fetchMessages(imap, range)
        
        // Create events for each new message
        for (const msg of messages) {
          const event = await this.eventStore.createEvent(
            EventTypes.MESSAGE_NEW,
            state.userEmail,
            {
              folder: state.folder,
              uid: msg.uid,
              from: msg.from,
              subject: msg.subject,
              date: msg.date,
              preview: msg.preview,
            }
          )
          
          // Broadcast to connected clients
          await this.clientManager.broadcastToUser(state.userEmail, event)
        }
        
        // Update uidnext
        state.uidnext = newUidnext
      }
      
      // Also send folder count update
      const status = await this.getFolderStatus(imap, state.folder)
      const countEvent = await this.eventStore.createEvent(
        EventTypes.FOLDER_COUNTS,
        state.userEmail,
        {
          folder: state.folder,
          total: status.messages,
          unread: status.unseen,
          uidnext: status.uidnext,
        }
      )
      await this.clientManager.broadcastToUser(state.userEmail, countEvent)
      
    } catch (error) {
      console.error(`[ImapIdle] Error handling new mail:`, error)
    }
  }

  /**
   * Handle message expunge (deletion)
   */
  async handleExpunge(state, seqno) {
    const event = await this.eventStore.createEvent(
      EventTypes.MESSAGE_DELETED,
      state.userEmail,
      {
        folder: state.folder,
        seqno,  // Note: seqno, not UID
        permanent: true,
      }
    )
    
    await this.clientManager.broadcastToUser(state.userEmail, event)
  }

  /**
   * Handle message update (flags changed)
   */
  async handleUpdate(state, seqno, info) {
    if (info && info.flags) {
      const event = await this.eventStore.createEvent(
        EventTypes.FLAGS_CHANGED,
        state.userEmail,
        {
          folder: state.folder,
          seqno,  // Note: seqno, not UID
          flags: info.flags,
        }
      )
      
      await this.clientManager.broadcastToUser(state.userEmail, event)
    }
  }

  /**
   * Handle disconnection with automatic reconnect
   */
  async handleDisconnect(userEmail, error = null) {
    const connection = this.connections.get(userEmail)
    if (!connection) return

    // Clear IDLE timer
    if (connection.state?.idleTimer) {
      clearTimeout(connection.state.idleTimer)
    }

    // Clean up
    this.connections.delete(userEmail)

    // Attempt reconnection if we have clients still connected
    if (this.clientManager.hasConnectedClients(userEmail)) {
      const attempts = this.reconnectAttempts.get(userEmail) || 0
      
      if (attempts < config.imap.maxReconnectAttempts) {
        this.reconnectAttempts.set(userEmail, attempts + 1)
        
        const delay = config.imap.reconnectDelay * Math.pow(2, attempts) // Exponential backoff
        console.log(`[ImapIdle] Reconnecting ${userEmail} in ${delay}ms (attempt ${attempts + 1})`)
        
        setTimeout(async () => {
          try {
            await this.startIdle(
              userEmail,
              connection.state.password,
              connection.state.folder,
              connection.state.options
            )
          } catch (e) {
            console.error(`[ImapIdle] Reconnection failed for ${userEmail}:`, e.message)
          }
        }, delay)
      } else {
        console.error(`[ImapIdle] Max reconnection attempts reached for ${userEmail}`)
        // Notify clients
        const event = await this.eventStore.createEvent(
          EventTypes.ERROR,
          userEmail,
          { code: 'IMAP_DISCONNECTED', message: 'IMAP connection lost' }
        )
        await this.clientManager.broadcastToUser(userEmail, event)
      }
    }
  }

  /**
   * Stop IDLE monitoring for a user
   */
  async stopIdle(userEmail) {
    const connection = this.connections.get(userEmail)
    if (!connection) return

    // Clear timer
    if (connection.state?.idleTimer) {
      clearTimeout(connection.state.idleTimer)
    }

    // Close connection
    try {
      connection.imap.end()
    } catch (e) {
      // Ignore
    }

    this.connections.delete(userEmail)
    this.reconnectAttempts.delete(userEmail)
    
    console.log(`[ImapIdle] Stopped monitoring for ${userEmail}`)
  }

  /**
   * Helper: Get UIDNEXT for a folder
   */
  getUidnext(imap, folder) {
    return new Promise((resolve, reject) => {
      imap.status(folder, (err, status) => {
        if (err) reject(err)
        else resolve(status.uidnext)
      })
    })
  }

  /**
   * Helper: Get folder status
   */
  getFolderStatus(imap, folder) {
    return new Promise((resolve, reject) => {
      imap.status(folder, (err, status) => {
        if (err) reject(err)
        else resolve(status)
      })
    })
  }

  /**
   * Helper: Fetch messages by UID range
   */
  fetchMessages(imap, range) {
    return new Promise((resolve, reject) => {
      const messages = []
      
      const fetch = imap.fetch(range, {
        bodies: ['HEADER.FIELDS (FROM SUBJECT DATE)'],
        struct: true,
      })

      fetch.on('message', (msg, seqno) => {
        const message = { seqno }
        
        msg.on('body', (stream, info) => {
          let buffer = ''
          stream.on('data', (chunk) => { buffer += chunk.toString('utf8') })
          stream.once('end', () => {
            const headers = Imap.parseHeader(buffer)
            message.from = headers.from?.[0] || ''
            message.subject = headers.subject?.[0] || ''
            message.date = headers.date?.[0] || ''
          })
        })
        
        msg.once('attributes', (attrs) => {
          message.uid = attrs.uid
          message.flags = attrs.flags
        })
        
        msg.once('end', () => {
          messages.push(message)
        })
      })

      fetch.once('error', reject)
      fetch.once('end', () => resolve(messages))
    })
  }

  /**
   * Get statistics
   */
  getStats() {
    return {
      activeConnections: this.connections.size,
      maxConnections: config.performance.maxIdleConnections,
      users: Array.from(this.connections.keys()),
    }
  }

  /**
   * Shutdown all connections
   */
  async shutdown() {
    for (const [userEmail, connection] of this.connections) {
      try {
        if (connection.state?.idleTimer) {
          clearTimeout(connection.state.idleTimer)
        }
        connection.imap.end()
      } catch (e) {
        // Ignore
      }
    }
    this.connections.clear()
    this.reconnectAttempts.clear()
    console.log('[ImapIdle] All connections closed')
  }
}

