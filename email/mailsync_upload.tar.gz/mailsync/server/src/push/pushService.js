/**
 * Push Notification Service for MailSync Server
 * 
 * Sends Web Push notifications to users who are offline (no WebSocket connection).
 * Reads push subscriptions from Redis (synced by PHP backend).
 * 
 * Uses the web-push npm package for VAPID authentication and payload encryption.
 */

import webpush from 'web-push'
import { config } from '../config.js'

export class PushService {
  constructor(redis, clientManager) {
    this.redis = redis
    this.clientManager = clientManager
    this.enabled = false
    
    // Initialize web-push with VAPID credentials
    if (config.push?.vapidPublicKey && config.push?.vapidPrivateKey && config.push?.vapidSubject) {
      try {
        webpush.setVapidDetails(
          config.push.vapidSubject,
          config.push.vapidPublicKey,
          config.push.vapidPrivateKey
        )
        this.enabled = true
        console.log('[PushService] Initialized with VAPID credentials')
      } catch (e) {
        console.error('[PushService] Failed to initialize VAPID:', e.message)
      }
    } else {
      console.log('[PushService] VAPID credentials not configured - push notifications disabled')
    }
  }

  /**
   * Check if push notifications are enabled
   */
  isEnabled() {
    return this.enabled
  }

  /**
   * Get push subscriptions for a user from Redis
   * PHP stores these at key: webmail:push_subs:{email}
   * 
   * @param {string} userEmail 
   * @returns {Array} Array of { endpoint, keys: { p256dh, auth } }
   */
  async getSubscriptions(userEmail) {
    try {
      const key = `${config.redis.prefix}push_subs:${userEmail.toLowerCase()}`
      const data = await this.redis.get(key)
      
      if (!data) return []
      
      const parsed = JSON.parse(data)
      return Array.isArray(parsed) ? parsed : []
    } catch (e) {
      console.error(`[PushService] Failed to get subscriptions for ${userEmail}:`, e.message)
      return []
    }
  }

  /**
   * Remove an invalid subscription from Redis
   * (Called when a push fails with 404/410 - subscription expired)
   */
  async removeSubscription(userEmail, endpoint) {
    try {
      const key = `${config.redis.prefix}push_subs:${userEmail.toLowerCase()}`
      const data = await this.redis.get(key)
      
      if (!data) return
      
      const subs = JSON.parse(data)
      const filtered = subs.filter(s => s.endpoint !== endpoint)
      
      if (filtered.length === 0) {
        await this.redis.del(key)
      } else {
        await this.redis.set(key, JSON.stringify(filtered), 'EX', 86400 * 30)
      }
      
      console.log(`[PushService] Removed expired subscription for ${userEmail}`)
    } catch (e) {
      console.error(`[PushService] Failed to remove subscription:`, e.message)
    }
  }

  /**
   * Send push notification to a user if they have no connected WebSocket clients
   * 
   * @param {string} userEmail - Target user email
   * @param {object} data - Event data { type, payload }
   */
  async sendPushIfOffline(userEmail, data) {
    if (!this.enabled) return
    
    // Only send push if user has NO connected WebSocket clients
    if (this.clientManager.hasConnectedClients(userEmail)) {
      return // User is online via WebSocket, they'll get real-time updates
    }

    // Build notification payload based on event type
    const notification = this.buildNotification(data)
    if (!notification) return // Not a pushable event type

    await this.sendPush(userEmail, notification)
  }

  /**
   * Build notification payload from event data
   * Returns null if the event type shouldn't trigger a push
   */
  buildNotification(data) {
    const { type, payload } = data

    switch (type) {
      case 'CHAT_MESSAGE_NEW': {
        const msg = payload?.message
        const convId = payload?.conversation_id
        if (!msg) return null
        
        const senderName = msg.sender_display_name || msg.sender_name || msg.sender_email || 'Someone'
        
        // Build clean preview - don't show raw encoded content
        // Check content_type first, then fallback to content pattern matching
        let preview
        if (msg.content_type === 'voice' || /^\[voice:\d/.test(msg.content)) {
          preview = 'Voice message'
        } else if (msg.content_type === 'image') {
          preview = 'Sent an image'
        } else if (/^\[gif:/.test(msg.content)) {
          preview = 'Sent a GIF'
        } else {
          preview = msg.content ? msg.content.substring(0, 100) : 'New message'
        }
        
        return {
          title: `${senderName}`,
          body: preview,
          type: 'chat',
          tag: `chat-${convId}`,
          conversationId: convId,
          url: `/chat?conversation=${convId}`
        }
      }

      case 'MESSAGE_NEW': {
        const from = payload?.from || 'Unknown sender'
        const subject = payload?.subject || 'No subject'
        const folder = payload?.folder || 'INBOX'
        
        return {
          title: `${from}`,
          body: subject.length > 100 ? subject.substring(0, 100) + '...' : subject,
          type: 'email',
          tag: `email-${payload?.uid || Date.now()}`,
          folder: folder,
          uid: payload?.uid,
          url: `/${folder}`
        }
      }

      case 'CALL_INCOMING': {
        const callerName = payload?.callerName || payload?.callerEmail?.split('@')[0] || 'Someone'
        const callTypeLabel = payload?.callType === 'video' ? 'video' : 'voice'
        
        return {
          title: `${callerName}`,
          body: `Incoming ${callTypeLabel} call`,
          type: 'call',
          tag: `call-${payload?.callId || Date.now()}`,
          conversationId: payload?.conversationId,
          url: `/chat?conversation=${payload?.conversationId}`
        }
      }

      case 'CALL_MISSED': {
        const callerName = payload?.callerName || payload?.callerEmail?.split('@')[0] || 'Someone'
        const callTypeLabel = payload?.callType === 'video' ? 'video' : 'voice'
        
        return {
          title: `Missed ${callTypeLabel} call`,
          body: `from ${callerName}`,
          type: 'missed_call',
          tag: `missed-call-${payload?.callId || Date.now()}`,
          conversationId: payload?.conversationId,
          url: `/chat?conversation=${payload?.conversationId}`
        }
      }

      default:
        return null // Don't push for other event types
    }
  }

  /**
   * Send push notification directly (bypasses offline check)
   * Used by call signaling when we already know the user is offline
   */
  async sendPushDirectly(userEmail, data) {
    if (!this.enabled) return
    
    const notification = this.buildNotification(data)
    if (!notification) return
    
    await this.sendPush(userEmail, notification)
  }

  /**
   * Send push notification to all subscriptions for a user
   */
  async sendPush(userEmail, notification) {
    const subscriptions = await this.getSubscriptions(userEmail)
    
    if (subscriptions.length === 0) return

    const payload = JSON.stringify(notification)

    for (const sub of subscriptions) {
      try {
        await webpush.sendNotification(sub, payload)
        console.log(`[PushService] Push sent to ${userEmail} (${sub.endpoint.substring(0, 50)}...)`)
      } catch (e) {
        if (e.statusCode === 404 || e.statusCode === 410) {
          // Subscription expired or invalid - remove it
          console.log(`[PushService] Subscription expired for ${userEmail} (${e.statusCode})`)
          await this.removeSubscription(userEmail, sub.endpoint)
        } else {
          console.error(`[PushService] Push failed for ${userEmail}:`, e.statusCode || e.message)
        }
      }
    }
  }
}

