/**
 * WebSocket Client Manager
 * 
 * Tracks connected clients and provides methods for broadcasting
 * events to specific users or all clients.
 */

import { config } from '../config.js'
import { ClientMessageTypes, EventTypes } from '../events/eventTypes.js'
import { v4 as uuidv4 } from 'uuid'

export class ClientManager {
  constructor() {
    // Map of userEmail -> Set<WebSocket>
    this.userClients = new Map()
    
    // Map of WebSocket -> client info
    this.clientInfo = new Map()
    
    // Processed event IDs per client (for idempotency on client side)
    // The server tracks this to help clients that reconnect
    this.clientLastVersion = new Map()
    
    // Heartbeat tracking
    this.heartbeatTimers = new Map()
    
    // Presence tracking: Map of userEmail -> { status, lastActivity, organizationDomain }
    this.userPresence = new Map()
    
    // Organization domains: Map of domain -> Set<userEmail>
    this.organizationUsers = new Map()
    
    // Away timeout (2 minutes of inactivity - reduced for better UX)
    this.AWAY_TIMEOUT = 2 * 60 * 1000
    
    // Presence check interval
    this.presenceCheckInterval = null
    this.startPresenceChecker()
  }
  
  /**
   * Start periodic presence checker (marks users as away after inactivity)
   */
  startPresenceChecker() {
    this.presenceCheckInterval = setInterval(() => {
      const now = Date.now()
      
      for (const [email, presence] of this.userPresence) {
        // Skip users who manually set their status
        if (presence.manualStatus) continue
        
        const timeSinceActivity = now - presence.lastActivity
        
        // If active and inactive for too long, mark as away
        if (presence.status === 'active' && timeSinceActivity > this.AWAY_TIMEOUT) {
          this.updateUserStatus(email, 'away', false)
        }
      }
    }, 60000) // Check every minute
  }

  /**
   * Add a new client connection
   * @param {WebSocket} ws - WebSocket connection
   * @param {object} userInfo - Decoded JWT payload
   */
  addClient(ws, userInfo) {
    const userEmail = userInfo.email
    
    // Add to user's client set
    if (!this.userClients.has(userEmail)) {
      this.userClients.set(userEmail, new Set())
    }
    this.userClients.get(userEmail).add(ws)
    
    // Store client info
    this.clientInfo.set(ws, {
      userEmail,
      userInfo,
      connectedAt: Date.now(),
      lastActivity: Date.now(),
      subscribedFolders: new Set(['INBOX']),  // Default to INBOX
      subscriptionMode: 'folders',  // 'folders' for web app, 'all' for desktop app
      subscriptions: new Set(),     // Additional subscriptions: 'calendars', 'boards', 'clients', 'drive'
    })
    
    // Start heartbeat monitoring
    this.startHeartbeat(ws)
    
    // Update presence - mark user as online
    const domain = this.getDomainFromEmail(userEmail)
    this.setUserOnline(userEmail, domain)
    
    console.log(`[ClientManager] Client connected: ${userEmail} (total: ${this.getTotalClients()})`)
  }
  
  /**
   * Extract domain from email
   */
  getDomainFromEmail(email) {
    return email.split('@')[1]?.toLowerCase() || ''
  }
  
  /**
   * Set user as online and broadcast to organization
   */
  setUserOnline(userEmail, domain) {
    const wasOffline = !this.userPresence.has(userEmail) || 
                       this.userPresence.get(userEmail).status === 'offline'
    
    // Track user in organization
    if (!this.organizationUsers.has(domain)) {
      this.organizationUsers.set(domain, new Set())
    }
    this.organizationUsers.get(domain).add(userEmail)
    
    // Set presence
    const existingPresence = this.userPresence.get(userEmail)
    this.userPresence.set(userEmail, {
      status: existingPresence?.manualStatus ? existingPresence.status : 'active',
      lastActivity: Date.now(),
      organizationDomain: domain,
      manualStatus: existingPresence?.manualStatus || false
    })
    
    // Broadcast presence change to organization if they were offline
    if (wasOffline) {
      this.broadcastPresenceToOrganization(domain, userEmail, 'active', EventTypes.PRESENCE_ONLINE)
    }
  }
  
  /**
   * Update user's activity timestamp (called on any user action)
   */
  updateUserActivity(userEmail) {
    const presence = this.userPresence.get(userEmail)
    if (presence) {
      const wasAway = presence.status === 'away'
      presence.lastActivity = Date.now()
      
      // If was away and not manually set, become active again
      if (wasAway && !presence.manualStatus) {
        presence.status = 'active'
        this.broadcastPresenceToOrganization(
          presence.organizationDomain, 
          userEmail, 
          'active',
          EventTypes.PRESENCE_STATUS_CHANGED
        )
      }
    }
  }
  
  /**
   * Update user's status (active, away, do_not_disturb)
   */
  updateUserStatus(userEmail, status, isManual = false) {
    const presence = this.userPresence.get(userEmail)
    if (presence && presence.status !== status) {
      presence.status = status
      presence.manualStatus = isManual
      presence.lastActivity = Date.now()
      
      this.broadcastPresenceToOrganization(
        presence.organizationDomain,
        userEmail,
        status,
        EventTypes.PRESENCE_STATUS_CHANGED
      )
    }
  }
  
  /**
   * Get current presence status for a user
   */
  getUserPresence(userEmail) {
    return this.userPresence.get(userEmail) || { status: 'offline', lastActivity: null }
  }
  
  /**
   * Get all online users in an organization
   */
  getOrganizationPresence(domain) {
    const users = this.organizationUsers.get(domain)
    if (!users) return {}
    
    const presence = {}
    for (const email of users) {
      const userPresence = this.userPresence.get(email)
      if (userPresence) {
        presence[email] = {
          status: userPresence.status,
          lastActivity: userPresence.lastActivity
        }
      }
    }
    return presence
  }
  
  /**
   * Broadcast presence update to all online users in an organization
   */
  broadcastPresenceToOrganization(domain, userEmail, status, eventType) {
    const orgUsers = this.organizationUsers.get(domain)
    if (!orgUsers) return
    
    const event = {
      eventId: uuidv4(),
      type: eventType,
      timestamp: Date.now(),
      payload: {
        userEmail,
        status,
        lastActivity: Date.now()
      }
    }
    
    // Broadcast to all users in the organization (except the one who changed)
    for (const email of orgUsers) {
      if (email !== userEmail && this.hasConnectedClients(email)) {
        this.broadcastToSubscribed(email, event, 'presence')
      }
    }
  }
  
  /**
   * Send bulk presence update to a newly connected user
   */
  sendBulkPresenceUpdate(ws, userEmail) {
    const info = this.clientInfo.get(ws)
    if (!info) return
    
    const domain = this.getDomainFromEmail(userEmail)
    const presence = this.getOrganizationPresence(domain)
    
    const event = {
      eventId: uuidv4(),
      type: EventTypes.PRESENCE_BULK_UPDATE,
      timestamp: Date.now(),
      payload: {
        presence
      }
    }
    
    this.sendToClient(ws, event)
  }

  /**
   * Remove a client connection
   * @param {WebSocket} ws 
   */
  removeClient(ws) {
    const info = this.clientInfo.get(ws)
    if (!info) return

    const userEmail = info.userEmail
    
    // Remove from user's client set
    const clients = this.userClients.get(userEmail)
    if (clients) {
      clients.delete(ws)
      if (clients.size === 0) {
        this.userClients.delete(userEmail)
        
        // User has no more connections - mark as offline
        this.setUserOffline(userEmail)
      }
    }
    
    // Clean up
    this.clientInfo.delete(ws)
    this.clientLastVersion.delete(ws)
    this.stopHeartbeat(ws)
    
    console.log(`[ClientManager] Client disconnected: ${userEmail} (total: ${this.getTotalClients()})`)
    
    return info
  }
  
  /**
   * Set user as offline and broadcast to organization
   */
  setUserOffline(userEmail) {
    const presence = this.userPresence.get(userEmail)
    if (!presence) return
    
    const domain = presence.organizationDomain
    
    // Broadcast offline status before removing
    this.broadcastPresenceToOrganization(domain, userEmail, 'offline', EventTypes.PRESENCE_OFFLINE)
    
    // Remove from presence tracking
    this.userPresence.delete(userEmail)
    
    // Remove from organization users
    const orgUsers = this.organizationUsers.get(domain)
    if (orgUsers) {
      orgUsers.delete(userEmail)
      if (orgUsers.size === 0) {
        this.organizationUsers.delete(domain)
      }
    }
  }

  /**
   * Get client info
   * @param {WebSocket} ws 
   * @returns {object|undefined}
   */
  getClientInfo(ws) {
    return this.clientInfo.get(ws)
  }

  /**
   * Update client's last activity time
   * @param {WebSocket} ws 
   */
  updateActivity(ws) {
    const info = this.clientInfo.get(ws)
    if (info) {
      info.lastActivity = Date.now()
    }
  }

  /**
   * Set client's last processed version (for reconnect replay)
   * @param {WebSocket} ws 
   * @param {number} version 
   */
  setLastVersion(ws, version) {
    this.clientLastVersion.set(ws, version)
  }

  /**
   * Get client's last processed version
   * @param {WebSocket} ws 
   * @returns {number}
   */
  getLastVersion(ws) {
    return this.clientLastVersion.get(ws) || 0
  }

  /**
   * Subscribe client to folder updates
   * @param {WebSocket} ws 
   * @param {string} folder 
   */
  subscribeToFolder(ws, folder) {
    const info = this.clientInfo.get(ws)
    if (info) {
      info.subscribedFolders.add(folder)
      console.log(`[ClientManager] ${info.userEmail} subscribed to ${folder}`)
    }
  }

  /**
   * Unsubscribe client from folder updates
   * @param {WebSocket} ws 
   * @param {string} folder 
   */
  unsubscribeFromFolder(ws, folder) {
    const info = this.clientInfo.get(ws)
    if (info) {
      info.subscribedFolders.delete(folder)
      console.log(`[ClientManager] ${info.userEmail} unsubscribed from ${folder}`)
    }
  }

  /**
   * Set subscription mode for desktop app
   * @param {WebSocket} ws 
   * @param {string} mode - 'folders' or 'all'
   */
  setSubscriptionMode(ws, mode) {
    const info = this.clientInfo.get(ws)
    if (info) {
      info.subscriptionMode = mode
      if (mode === 'all') {
        // Subscribe to all entity types
        info.subscriptions.add('calendars')
        info.subscriptions.add('boards')
        info.subscriptions.add('clients')
        info.subscriptions.add('drive')
        info.subscriptions.add('todos')
        info.subscriptions.add('chat')
        info.subscriptions.add('presence')
      }
    }
  }

  /**
   * Add entity subscription (calendars, boards, clients, drive)
   * @param {WebSocket} ws 
   * @param {string} entityType 
   */
  addSubscription(ws, entityType) {
    const info = this.clientInfo.get(ws)
    if (info) {
      info.subscriptions.add(entityType)
    }
  }

  /**
   * Remove entity subscription
   * @param {WebSocket} ws 
   * @param {string} entityType 
   */
  removeSubscription(ws, entityType) {
    const info = this.clientInfo.get(ws)
    if (info) {
      info.subscriptions.delete(entityType)
    }
  }

  /**
   * Check if client is subscribed to entity type
   * @param {WebSocket} ws 
   * @param {string} entityType 
   * @returns {boolean}
   */
  isSubscribedTo(ws, entityType) {
    const info = this.clientInfo.get(ws)
    if (!info) return false
    
    // 'all' mode subscribes to everything
    if (info.subscriptionMode === 'all') return true
    
    return info.subscriptions.has(entityType)
  }

  /**
   * Broadcast event to subscribed clients only
   * @param {string} userEmail 
   * @param {object} event 
   * @param {string} entityType - Type of entity (calendars, boards, clients, drive)
   */
  async broadcastToSubscribed(userEmail, event, entityType) {
    const clients = this.userClients.get(userEmail)
    if (!clients || clients.size === 0) {
      return 0
    }

    const message = JSON.stringify(event)
    let delivered = 0

    for (const ws of clients) {
      try {
        if (ws.readyState === 1 && this.isSubscribedTo(ws, entityType)) {
          ws.send(message)
          delivered++
        }
      } catch (error) {
        console.error(`[ClientManager] Failed to send to client:`, error)
      }
    }

    return delivered
  }

  /**
   * Get all connected users
   * @returns {string[]}
   */
  getConnectedUsers() {
    return Array.from(this.userClients.keys())
  }

  /**
   * Check if user has any connected clients
   * @param {string} userEmail 
   * @returns {boolean}
   */
  hasConnectedClients(userEmail) {
    const clients = this.userClients.get(userEmail)
    return clients && clients.size > 0
  }

  /**
   * Get number of connected clients for a user
   * @param {string} userEmail 
   * @returns {number}
   */
  getClientCount(userEmail) {
    const clients = this.userClients.get(userEmail)
    return clients ? clients.size : 0
  }

  /**
   * Get total number of connected clients
   * @returns {number}
   */
  getTotalClients() {
    let total = 0
    for (const clients of this.userClients.values()) {
      total += clients.size
    }
    return total
  }

  /**
   * Broadcast event to all clients of a user
   * @param {string} userEmail 
   * @param {object} event 
   */
  async broadcastToUser(userEmail, event) {
    const clients = this.userClients.get(userEmail)
    if (!clients || clients.size === 0) {
      return 0
    }

    const message = JSON.stringify(event)
    let delivered = 0

    for (const ws of clients) {
      try {
        if (ws.readyState === 1) {  // WebSocket.OPEN
          ws.send(message)
          delivered++
        }
      } catch (error) {
        console.error(`[ClientManager] Failed to send to client:`, error)
      }
    }

    return delivered
  }

  /**
   * Broadcast event to all connected clients
   * @param {object} event 
   */
  async broadcastToAll(event) {
    const message = JSON.stringify(event)
    let delivered = 0

    for (const [userEmail, clients] of this.userClients) {
      for (const ws of clients) {
        try {
          if (ws.readyState === 1) {
            ws.send(message)
            delivered++
          }
        } catch (error) {
          console.error(`[ClientManager] Failed to send to client:`, error)
        }
      }
    }

    return delivered
  }

  /**
   * Send event to specific client
   * @param {WebSocket} ws 
   * @param {object} event 
   */
  sendToClient(ws, event) {
    try {
      if (ws.readyState === 1) {
        ws.send(JSON.stringify(event))
        return true
      }
    } catch (error) {
      console.error(`[ClientManager] Failed to send to client:`, error)
    }
    return false
  }

  /**
   * Start heartbeat monitoring for a client
   * @param {WebSocket} ws 
   */
  startHeartbeat(ws) {
    const timer = setInterval(() => {
      const info = this.clientInfo.get(ws)
      if (!info) {
        this.stopHeartbeat(ws)
        return
      }

      const timeSinceActivity = Date.now() - info.lastActivity
      
      // If client hasn't responded in timeout period, disconnect
      if (timeSinceActivity > config.performance.clientTimeout) {
        console.log(`[ClientManager] Client timeout: ${info.userEmail}`)
        ws.terminate()
        this.removeClient(ws)
        return
      }

      // Send ping
      if (ws.readyState === 1) {
        ws.ping()
      }
    }, config.performance.heartbeatInterval)

    this.heartbeatTimers.set(ws, timer)
  }

  /**
   * Stop heartbeat monitoring for a client
   * @param {WebSocket} ws 
   */
  stopHeartbeat(ws) {
    const timer = this.heartbeatTimers.get(ws)
    if (timer) {
      clearInterval(timer)
      this.heartbeatTimers.delete(ws)
    }
  }

  /**
   * Get statistics
   * @returns {object}
   */
  getStats() {
    const stats = {
      totalClients: this.getTotalClients(),
      uniqueUsers: this.userClients.size,
      userStats: {},
    }

    for (const [userEmail, clients] of this.userClients) {
      stats.userStats[userEmail] = {
        clients: clients.size,
      }
    }

    return stats
  }

  /**
   * Shutdown - close all connections
   */
  async shutdown() {
    // Stop presence checker
    if (this.presenceCheckInterval) {
      clearInterval(this.presenceCheckInterval)
      this.presenceCheckInterval = null
    }
    
    for (const [ws, info] of this.clientInfo) {
      try {
        this.stopHeartbeat(ws)
        ws.close(1001, 'Server shutting down')
      } catch (e) {
        // Ignore
      }
    }
    
    this.userClients.clear()
    this.clientInfo.clear()
    this.clientLastVersion.clear()
    this.userPresence.clear()
    this.organizationUsers.clear()
    
    console.log('[ClientManager] All clients disconnected')
  }
}

