/**
 * Mail Sync WebSocket Server
 * 
 * Real-time email synchronization server using:
 * - WebSocket for client connections
 * - IMAP IDLE for instant new mail detection
 * - Redis pub/sub for events from PHP backend
 * 
 * All events include unique eventId and are idempotent.
 */

import { WebSocketServer } from 'ws'
import { createServer } from 'http'
import { createServer as createHttpsServer } from 'https'
import { readFileSync } from 'fs'
import Redis from 'ioredis'

import { config } from './config.js'
import { validateToken, extractTokenFromRequest, isTokenExpiringSoon } from './auth/jwtValidator.js'
import { EventStore } from './events/eventStore.js'
import { EventTypes, ClientMessageTypes } from './events/eventTypes.js'
import { ClientManager } from './clients/clientManager.js'
import { RedisPubSub } from './redis/pubsub.js'
import { ImapIdleManager } from './imap/idleManager.js'
import { PushService } from './push/pushService.js'
import {
  handleCallInitiate,
  handleCallAnswer,
  handleCallReject,
  handleCallHangup,
  handleCallIceCandidate,
  handleCallMediaState,
  handleCallScreenShare,
  cleanupAllCalls
} from './calls/callSignaling.js'

// Global instances
let redis = null
let redisSubscriber = null
let eventStore = null
let clientManager = null
let redisPubSub = null
let imapIdleManager = null
let pushService = null
let wss = null
let server = null

/**
 * Initialize the server
 */
async function init() {
  console.log('[MailSync] Starting server...')
  console.log(`[MailSync] Config: WS port ${config.ws.port}, Redis ${config.redis.host}:${config.redis.port}`)

  // Initialize Redis connections
  const redisConfig = {
    host: config.redis.host,
    port: config.redis.port,
    password: config.redis.password || undefined,
    db: config.redis.database,
    retryDelayOnFailover: 100,
    maxRetriesPerRequest: 3,
  }

  redis = new Redis(redisConfig)
  redisSubscriber = new Redis(redisConfig)  // Separate connection for pub/sub

  redis.on('connect', () => console.log('[Redis] Connected'))
  redis.on('error', (err) => console.error('[Redis] Error:', err.message))

  // Initialize components
  eventStore = new EventStore(redis)
  await eventStore.init()

  clientManager = new ClientManager()

  // Initialize push notification service (for offline users)
  pushService = new PushService(redis, clientManager)

  redisPubSub = new RedisPubSub(redisSubscriber, eventStore, clientManager, pushService)
  await redisPubSub.init()

  imapIdleManager = new ImapIdleManager(
    eventStore,
    clientManager,
    (userEmail, type, payload) => redisPubSub.publishEvent(userEmail, type, payload)
  )

  // Create HTTP(S) server
  if (config.ssl.enabled) {
    const sslOptions = {
      key: readFileSync(config.ssl.keyPath),
      cert: readFileSync(config.ssl.certPath),
    }
    server = createHttpsServer(sslOptions)
    console.log('[MailSync] SSL enabled')
  } else {
    server = createServer()
  }

  // Create WebSocket server
  wss = new WebSocketServer({ server })

  // Handle WebSocket connections
  wss.on('connection', handleConnection)

  // Start listening
  server.listen(config.ws.port, config.ws.host, () => {
    console.log(`[MailSync] WebSocket server running on ${config.ws.host}:${config.ws.port}`)
  })

  // Graceful shutdown
  process.on('SIGINT', shutdown)
  process.on('SIGTERM', shutdown)
}

/**
 * Complete client setup after authentication
 * @param {WebSocket} ws 
 * @param {object} userInfo - Validated user info from JWT
 */
async function completeAuthentication(ws, userInfo) {
  // Add client to manager
  clientManager.addClient(ws, userInfo)

  // Send connected event with current version
  const currentVersion = await eventStore.getCurrentVersion(userInfo.email)
  const connectedEvent = await eventStore.createEvent(
    EventTypes.CONNECTED,
    userInfo.email,
    {
      serverTime: Date.now(),
      currentVersion,
    }
  )
  clientManager.sendToClient(ws, connectedEvent)

  console.log(`[MailSync] Client authenticated: ${userInfo.email}`)
}

/**
 * Handle new WebSocket connection
 * Supports two auth modes:
 * 1. (Preferred) No URL token - client sends AUTHENTICATE message after open
 * 2. (Legacy/backward compat) Token in URL query param
 * 
 * @param {WebSocket} ws 
 * @param {IncomingMessage} request 
 */
async function handleConnection(ws, request) {
  // Try legacy auth via URL/headers first (backward compat)
  const token = extractTokenFromRequest(request)
  let userInfo = validateToken(token)
  let isAuthenticated = false

  if (userInfo) {
    // Legacy path: token was in URL, authenticate immediately
    if (isTokenExpiringSoon(userInfo)) {
      console.log(`[MailSync] Warning: token expiring soon for ${userInfo.email}`)
    }
    await completeAuthentication(ws, userInfo)
    isAuthenticated = true
  }

  // Set an auth timeout: if no AUTHENTICATE message in 10s, disconnect
  let authTimeout = null
  if (!isAuthenticated) {
    authTimeout = setTimeout(() => {
      if (!clientManager.getClientInfo(ws)) {
        console.log('[MailSync] Connection rejected: auth timeout')
        ws.close(4001, 'Authentication timeout')
      }
    }, 10000)
  }

  // Handle incoming messages
  ws.on('message', async (data) => {
    try {
      const message = JSON.parse(data.toString())

      // Handle AUTHENTICATE message (new secure path)
      if (message.type === 'AUTHENTICATE' && !isAuthenticated) {
        const authInfo = validateToken(message.token)
        if (!authInfo) {
          console.log('[MailSync] Connection rejected: invalid auth token in message')
          ws.close(4001, 'Unauthorized')
          return
        }
        if (isTokenExpiringSoon(authInfo)) {
          console.log(`[MailSync] Warning: token expiring soon for ${authInfo.email}`)
        }
        isAuthenticated = true
        if (authTimeout) {
          clearTimeout(authTimeout)
          authTimeout = null
        }
        await completeAuthentication(ws, authInfo)
        return
      }

      // All other messages require authentication
      if (!isAuthenticated) {
        clientManager.sendToClient(ws, { type: 'ERROR', payload: { code: 'NOT_AUTHENTICATED', message: 'Send AUTHENTICATE message first' } })
        return
      }

      // Forward to existing message handler
      await handleClientMessage(ws, data)
    } catch (e) {
      // If the message handler below re-parses, that's fine - it's idempotent
      if (isAuthenticated) {
        await handleClientMessage(ws, data)
      }
    }
  })

  // Handle pong (heartbeat response)
  ws.on('pong', () => {
    clientManager.updateActivity(ws)
  })

  // Handle close
  ws.on('close', (code, reason) => {
    if (authTimeout) {
      clearTimeout(authTimeout)
    }
    const info = clientManager.removeClient(ws)
    if (info) {
      // Check if this was the last client for this user
      if (!clientManager.hasConnectedClients(info.userEmail)) {
        // Stop IMAP IDLE for this user (no more clients)
        imapIdleManager.stopIdle(info.userEmail)
      }
    }
  })

  // Handle errors
  ws.on('error', (error) => {
    const info = clientManager.getClientInfo(ws)
    const email = info ? info.userEmail : 'unknown'
    console.error(`[MailSync] WebSocket error for ${email}:`, error.message)
  })
}

/**
 * Handle incoming message from client
 * @param {WebSocket} ws 
 * @param {Buffer} data 
 */
async function handleClientMessage(ws, data) {
  const info = clientManager.getClientInfo(ws)
  if (!info) return

  clientManager.updateActivity(ws)

  try {
    const message = JSON.parse(data.toString())
    
    switch (message.type) {
      case ClientMessageTypes.PING:
        // Respond with pong
        clientManager.sendToClient(ws, { type: 'PONG', timestamp: Date.now() })
        break

      case ClientMessageTypes.SUBSCRIBE_FOLDER:
        // Subscribe to folder IDLE
        if (message.folder) {
          clientManager.subscribeToFolder(ws, message.folder)
          
          // If IMAP credentials provided, start IDLE
          if (message.password) {
            try {
              await imapIdleManager.startIdle(
                info.userEmail,
                message.password,
                message.folder,
                message.options || {}
              )
            } catch (e) {
              console.error(`[MailSync] Failed to start IDLE:`, e.message)
              clientManager.sendToClient(ws, {
                type: EventTypes.ERROR,
                payload: { code: 'IMAP_CONNECT_FAILED', message: e.message }
              })
            }
          }
        }
        break

      case ClientMessageTypes.UNSUBSCRIBE_FOLDER:
        if (message.folder) {
          clientManager.unsubscribeFromFolder(ws, message.folder)
        }
        break

      case ClientMessageTypes.REPLAY_EVENTS:
        // Client requesting missed events
        const sinceVersion = message.sinceVersion || 0
        const events = await eventStore.getEventsSince(info.userEmail, sinceVersion)
        
        // Send events in order
        for (const event of events) {
          clientManager.sendToClient(ws, event)
        }
        
        // Send sync complete notification
        clientManager.sendToClient(ws, {
          type: EventTypes.SYNC_STATUS,
          payload: {
            status: 'replay_complete',
            eventCount: events.length,
            currentVersion: await eventStore.getCurrentVersion(info.userEmail),
          }
        })
        break

      case ClientMessageTypes.ACK_EVENT:
        // Client acknowledging event receipt
        if (message.version) {
          clientManager.setLastVersion(ws, message.version)
        }
        break

      // ============================================
      // DESKTOP APP SUBSCRIPTION HANDLERS
      // ============================================
      
      case ClientMessageTypes.SUBSCRIBE_ALL:
        // Desktop app subscribing to all events
        clientManager.setSubscriptionMode(ws, 'all')
        console.log(`[MailSync] Client ${info.userEmail} subscribed to ALL events (desktop mode)`)
        
        // Send sync status
        clientManager.sendToClient(ws, {
          type: EventTypes.SYNC_STATUS,
          payload: {
            status: 'subscribed',
            mode: 'all',
            currentVersion: await eventStore.getCurrentVersion(info.userEmail),
          }
        })
        
        // Send current presence state (since SUBSCRIBE_ALL includes presence)
        clientManager.sendBulkPresenceUpdate(ws, info.userEmail)
        break

      case ClientMessageTypes.SUBSCRIBE_CALENDARS:
        clientManager.addSubscription(ws, 'calendars')
        console.log(`[MailSync] Client ${info.userEmail} subscribed to calendar events`)
        break

      case ClientMessageTypes.SUBSCRIBE_BOARDS:
        clientManager.addSubscription(ws, 'boards')
        console.log(`[MailSync] Client ${info.userEmail} subscribed to board events`)
        break

      case ClientMessageTypes.SUBSCRIBE_CLIENTS:
        clientManager.addSubscription(ws, 'clients')
        console.log(`[MailSync] Client ${info.userEmail} subscribed to client events`)
        break

      case ClientMessageTypes.SUBSCRIBE_DRIVE:
        clientManager.addSubscription(ws, 'drive')
        console.log(`[MailSync] Client ${info.userEmail} subscribed to drive events`)
        break

      case ClientMessageTypes.SUBSCRIBE_CHAT:
        clientManager.addSubscription(ws, 'chat')
        console.log(`[MailSync] Client ${info.userEmail} subscribed to chat events`)
        break

      case ClientMessageTypes.UNSUBSCRIBE_CALENDARS:
        clientManager.removeSubscription(ws, 'calendars')
        break

      case ClientMessageTypes.UNSUBSCRIBE_BOARDS:
        clientManager.removeSubscription(ws, 'boards')
        break

      case ClientMessageTypes.UNSUBSCRIBE_CLIENTS:
        clientManager.removeSubscription(ws, 'clients')
        break

      case ClientMessageTypes.UNSUBSCRIBE_DRIVE:
        clientManager.removeSubscription(ws, 'drive')
        break

      case ClientMessageTypes.UNSUBSCRIBE_CHAT:
        clientManager.removeSubscription(ws, 'chat')
        break

      // ============================================
      // CALL SIGNALING HANDLERS
      // ============================================
      
      case ClientMessageTypes.CALL_INITIATE:
        await handleCallInitiate(ws, info, message, clientManager, eventStore, redisPubSub)
        break

      case ClientMessageTypes.CALL_ANSWER:
        await handleCallAnswer(ws, info, message, clientManager, eventStore)
        break

      case ClientMessageTypes.CALL_REJECT:
        await handleCallReject(ws, info, message, clientManager, eventStore)
        break

      case ClientMessageTypes.CALL_HANGUP:
        await handleCallHangup(ws, info, message, clientManager, eventStore)
        break

      case ClientMessageTypes.CALL_ICE_CANDIDATE:
        await handleCallIceCandidate(ws, info, message, clientManager, eventStore)
        break

      case ClientMessageTypes.CALL_MEDIA_STATE:
        await handleCallMediaState(ws, info, message, clientManager, eventStore)
        break

      case ClientMessageTypes.CALL_SCREEN_SHARE_START:
        await handleCallScreenShare(ws, info, message, clientManager, eventStore, true)
        break

      case ClientMessageTypes.CALL_SCREEN_SHARE_STOP:
        await handleCallScreenShare(ws, info, message, clientManager, eventStore, false)
        break

      // ============================================
      // PRESENCE HANDLERS
      // ============================================
      
      case ClientMessageTypes.SUBSCRIBE_PRESENCE:
        // Subscribe to presence updates for organization
        clientManager.addSubscription(ws, 'presence')
        console.log(`[MailSync] Client ${info.userEmail} subscribed to presence events`)
        
        // Send current presence state for organization
        clientManager.sendBulkPresenceUpdate(ws, info.userEmail)
        break
      
      case ClientMessageTypes.PRESENCE_UPDATE:
        // User manually updating their status (active, away, do_not_disturb)
        if (message.status && ['active', 'away', 'do_not_disturb'].includes(message.status)) {
          clientManager.updateUserStatus(info.userEmail, message.status, true) // true = manual
          console.log(`[MailSync] ${info.userEmail} set status to: ${message.status}`)
        }
        break
      
      case ClientMessageTypes.PRESENCE_HEARTBEAT:
        // User activity heartbeat (keeps status as active, prevents auto-away)
        clientManager.updateUserActivity(info.userEmail)
        break

      default:
        console.warn(`[MailSync] Unknown message type: ${message.type}`)
    }
  } catch (error) {
    console.error('[MailSync] Error parsing message:', error)
  }
}

/**
 * Graceful shutdown with timeout
 */
async function shutdown() {
  console.log('\n[MailSync] Shutting down...')

  // Force exit after 3 seconds if graceful shutdown hangs
  const forceExitTimer = setTimeout(() => {
    console.log('[MailSync] Force exit (timeout)')
    process.exit(0)
  }, 3000)

  try {
    // Clean up active calls
    cleanupAllCalls()

    // Close WebSocket server
    if (wss) {
      wss.close()
    }

    // Shutdown components
    if (clientManager) {
      await clientManager.shutdown()
    }

    if (imapIdleManager) {
      await imapIdleManager.shutdown()
    }

    if (redisPubSub) {
      await redisPubSub.shutdown()
    }

    if (eventStore) {
      await eventStore.shutdown()
    }

    // Close Redis connections (use disconnect instead of quit for faster shutdown)
    if (redis) {
      redis.disconnect()
    }
    if (redisSubscriber) {
      redisSubscriber.disconnect()
    }

    // Close HTTP server
    if (server) {
      server.close()
    }

    clearTimeout(forceExitTimer)
    console.log('[MailSync] Shutdown complete')
    process.exit(0)
  } catch (error) {
    clearTimeout(forceExitTimer)
    console.error('[MailSync] Error during shutdown:', error)
    process.exit(1)
  }
}

// Start the server
init().catch((error) => {
  console.error('[MailSync] Failed to start:', error)
  process.exit(1)
})

