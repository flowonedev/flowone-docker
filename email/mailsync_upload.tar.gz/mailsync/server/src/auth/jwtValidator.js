/**
 * JWT Validator
 * 
 * Validates JWT tokens from the PHP backend.
 * Tokens must use the same secret and algorithm as the PHP backend.
 */

import jwt from 'jsonwebtoken'
import { config } from '../config.js'

/**
 * Validate a JWT token and extract user info
 * @param {string} token - JWT token from client
 * @returns {object|null} Decoded token payload or null if invalid
 */
export function validateToken(token) {
  if (!token) {
    return null
  }

  try {
    // Remove 'Bearer ' prefix if present
    const cleanToken = token.startsWith('Bearer ') ? token.slice(7) : token

    if (!config.jwt.secret) {
      console.error('[JWT] FATAL: JWT secret is empty! Set JWT_SECRET in mailsync .env (must match backend)')
      return null
    }

    const decoded = jwt.verify(cleanToken, config.jwt.secret, {
      algorithms: [config.jwt.algorithm],
    })

    // Validate required fields - PHP backend uses 'sub' (subject) for email
    const email = decoded.email || decoded.sub
    if (!email) {
      console.error('[JWT] Token missing email/sub field')
      return null
    }

    return {
      email: email,
      exp: decoded.exp,
      iat: decoded.iat,
      // Include any other fields from the token
      ...decoded,
    }
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      console.log('[JWT] Token expired')
    } else if (error.name === 'JsonWebTokenError') {
      console.error('[JWT] Invalid token:', error.message)
    } else {
      console.error('[JWT] Validation error:', error)
    }
    return null
  }
}

/**
 * Check if a token is about to expire (within threshold)
 * @param {object} decoded - Decoded token
 * @param {number} thresholdSeconds - Seconds before expiry to consider "expiring soon"
 * @returns {boolean} True if expiring soon
 */
export function isTokenExpiringSoon(decoded, thresholdSeconds = 300) {
  if (!decoded || !decoded.exp) {
    return true
  }
  
  const now = Math.floor(Date.now() / 1000)
  return decoded.exp - now < thresholdSeconds
}

/**
 * Extract token from WebSocket upgrade request
 * @param {object} request - HTTP upgrade request
 * @returns {string|null} Token or null
 */
export function extractTokenFromRequest(request) {
  // Try Authorization header first
  const authHeader = request.headers['authorization']
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.slice(7)
  }

  // Try query parameter (for WebSocket connections)
  const url = new URL(request.url, `http://${request.headers.host}`)
  const tokenParam = url.searchParams.get('token')
  if (tokenParam) {
    return tokenParam
  }

  // Try Sec-WebSocket-Protocol header (alternative method)
  const protocol = request.headers['sec-websocket-protocol']
  if (protocol) {
    // Protocol can be comma-separated, token would be one of them
    const protocols = protocol.split(',').map(p => p.trim())
    for (const p of protocols) {
      if (p.startsWith('token.')) {
        return p.slice(6)
      }
    }
  }

  return null
}

