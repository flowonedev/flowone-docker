/**
 * Call Signaling Handler
 * 
 * Manages WebRTC call signaling through the existing WebSocket infrastructure.
 * Tracks active calls in memory (Redis-backed for multi-instance scaling).
 * 
 * Flow:
 * 1. Caller sends CALL_INITIATE -> relayed to all participants in conversation
 * 2. Callee sends CALL_ANSWER -> relayed back to caller
 * 3. ICE candidates exchanged bidirectionally
 * 4. CALL_HANGUP from either party ends the call
 */

import { EventTypes, ClientMessageTypes } from '../events/eventTypes.js'

// In-memory active calls: callId -> { conversationId, callType, initiatedBy, participants, startedAt }
const activeCalls = new Map()

// Timeout for unanswered calls (30 seconds)
const CALL_TIMEOUT = 30000

// Active call timers for auto-hangup on no answer
const callTimers = new Map()

/**
 * Generate a unique call ID
 */
function generateCallId() {
  return `call_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

/**
 * Handle CALL_INITIATE message from client
 * Creates a new call and notifies other participants
 */
export async function handleCallInitiate(ws, clientInfo, message, clientManager, eventStore, redisPubSub) {
  const { conversationId, callType, participants } = message
  
  if (!conversationId || !callType || !['voice', 'video'].includes(callType)) {
    clientManager.sendToClient(ws, {
      type: EventTypes.ERROR,
      payload: { code: 'INVALID_CALL', message: 'Invalid call parameters' }
    })
    return
  }
  
  if (!participants || !Array.isArray(participants) || participants.length === 0) {
    clientManager.sendToClient(ws, {
      type: EventTypes.ERROR,
      payload: { code: 'INVALID_CALL', message: 'No participants specified' }
    })
    return
  }
  
  // Check if there's already an active call in this conversation
  for (const [, call] of activeCalls) {
    if (call.conversationId === conversationId) {
      clientManager.sendToClient(ws, {
        type: EventTypes.ERROR,
        payload: { code: 'CALL_IN_PROGRESS', message: 'A call is already in progress in this conversation' }
      })
      return
    }
  }
  
  const callId = generateCallId()
  const callerEmail = clientInfo.userEmail
  
  // Store active call
  activeCalls.set(callId, {
    conversationId,
    callType,
    initiatedBy: callerEmail,
    participants: [callerEmail, ...participants],
    startedAt: Date.now(),
    answeredAt: null,
    status: 'ringing'
  })
  
  console.log(`[CallSignaling] Call initiated: ${callId} by ${callerEmail} (${callType}) to ${participants.join(', ')}`)
  
  // Send CALL_INITIATE to all other participants
  // Use broadcastToUser (not broadcastToSubscribed) to ensure delivery
  // even if the callee hasn't explicitly subscribed to chat events
  for (const participantEmail of participants) {
    if (participantEmail === callerEmail) continue
    
    const event = await eventStore.createEvent(
      EventTypes.CALL_INITIATE,
      participantEmail,
      {
        callId,
        conversationId,
        callType,
        callerEmail,
        callerName: clientInfo.userInfo?.name || callerEmail.split('@')[0],
        participants: [callerEmail, ...participants],
        sdp: message.sdp || null  // Forward caller's SDP offer to callee
      }
    )
    const delivered = await clientManager.broadcastToUser(participantEmail, event)
    console.log(`[CallSignaling] CALL_INITIATE -> ${participantEmail}: delivered to ${delivered} client(s)`)
  }
  
  // Confirm to caller that call was initiated
  clientManager.sendToClient(ws, {
    type: EventTypes.CALL_RINGING,
    payload: {
      callId,
      conversationId,
      callType,
      participants: [callerEmail, ...participants]
    }
  })
  
  // Send push notification to offline participants (they won't get the WebSocket event)
  for (const participantEmail of participants) {
    if (participantEmail === callerEmail) continue
    
    if (!clientManager.hasConnectedClients(participantEmail)) {
      console.log(`[CallSignaling] ${participantEmail} is offline, sending push for incoming call`)
      // We'll handle this via pushService if available
      if (redisPubSub?.pushService) {
        redisPubSub.pushService.sendPushDirectly(participantEmail, {
          type: 'CALL_INCOMING',
          payload: {
            callId,
            conversationId,
            callType,
            callerEmail,
            callerName: clientInfo.userInfo?.name || callerEmail.split('@')[0]
          }
        }).catch(err => {
          console.error(`[CallSignaling] Push notification error for ${participantEmail}:`, err.message)
        })
      }
    }
  }
  
  // Set timeout for unanswered call
  const pushSvc = redisPubSub?.pushService || null
  const timer = setTimeout(async () => {
    const call = activeCalls.get(callId)
    if (call && call.status === 'ringing') {
      // Call was not answered - send missed notification
      await handleCallTimeout(callId, clientManager, eventStore, pushSvc)
    }
  }, CALL_TIMEOUT)
  
  callTimers.set(callId, timer)
}

/**
 * Handle CALL_ANSWER message
 */
export async function handleCallAnswer(ws, clientInfo, message, clientManager, eventStore) {
  const { callId, sdp } = message
  const call = activeCalls.get(callId)
  
  if (!call) {
    clientManager.sendToClient(ws, {
      type: EventTypes.ERROR,
      payload: { code: 'CALL_NOT_FOUND', message: 'Call not found or already ended' }
    })
    return
  }
  
  call.status = 'active'
  call.answeredAt = Date.now()
  
  // Clear the timeout timer
  const timer = callTimers.get(callId)
  if (timer) {
    clearTimeout(timer)
    callTimers.delete(callId)
  }
  
  console.log(`[CallSignaling] Call answered: ${callId} by ${clientInfo.userEmail}`)
  
  // Notify all other participants that the call was answered
  for (const participantEmail of call.participants) {
    if (participantEmail === clientInfo.userEmail) continue
    
    const event = await eventStore.createEvent(
      EventTypes.CALL_ANSWER,
      participantEmail,
      {
        callId,
        conversationId: call.conversationId,
        answeredBy: clientInfo.userEmail,
        sdp
      }
    )
    await clientManager.broadcastToUser(participantEmail, event)
  }
}

/**
 * Handle CALL_REJECT message
 */
export async function handleCallReject(ws, clientInfo, message, clientManager, eventStore) {
  const { callId, reason } = message
  const call = activeCalls.get(callId)
  
  if (!call) return
  
  console.log(`[CallSignaling] Call rejected: ${callId} by ${clientInfo.userEmail} (${reason || 'declined'})`)
  
  // Clear timeout
  const timer = callTimers.get(callId)
  if (timer) {
    clearTimeout(timer)
    callTimers.delete(callId)
  }
  
  // Notify all other participants
  for (const participantEmail of call.participants) {
    if (participantEmail === clientInfo.userEmail) continue
    
    const event = await eventStore.createEvent(
      EventTypes.CALL_REJECT,
      participantEmail,
      {
        callId,
        conversationId: call.conversationId,
        rejectedBy: clientInfo.userEmail,
        reason: reason || 'declined'
      }
    )
    await clientManager.broadcastToUser(participantEmail, event)
  }
  
  // If all participants rejected, end the call
  // For now (DM), any rejection ends the call
  activeCalls.delete(callId)
}

/**
 * Handle CALL_HANGUP message
 */
export async function handleCallHangup(ws, clientInfo, message, clientManager, eventStore) {
  const { callId } = message
  const call = activeCalls.get(callId)
  
  if (!call) return
  
  const duration = call.answeredAt ? Math.floor((Date.now() - call.answeredAt) / 1000) : 0
  
  console.log(`[CallSignaling] Call ended: ${callId} by ${clientInfo.userEmail} (duration: ${duration}s)`)
  
  // Clear timeout
  const timer = callTimers.get(callId)
  if (timer) {
    clearTimeout(timer)
    callTimers.delete(callId)
  }
  
  // Notify all other participants
  for (const participantEmail of call.participants) {
    if (participantEmail === clientInfo.userEmail) continue
    
    const event = await eventStore.createEvent(
      EventTypes.CALL_HANGUP,
      participantEmail,
      {
        callId,
        conversationId: call.conversationId,
        hungUpBy: clientInfo.userEmail,
        duration,
        callType: call.callType
      }
    )
    await clientManager.broadcastToUser(participantEmail, event)
  }
  
  activeCalls.delete(callId)
}

/**
 * Handle CALL_ICE_CANDIDATE message
 * Relay ICE candidate to the target participant
 */
export async function handleCallIceCandidate(ws, clientInfo, message, clientManager, eventStore) {
  const { callId, candidate, targetEmail } = message
  const call = activeCalls.get(callId)
  
  if (!call) return
  
  // Relay to target participant (or all others if no target specified)
  const targets = targetEmail
    ? [targetEmail]
    : call.participants.filter(e => e !== clientInfo.userEmail)
  
  for (const email of targets) {
    const event = await eventStore.createEvent(
      EventTypes.CALL_ICE_CANDIDATE,
      email,
      {
        callId,
        candidate,
        fromEmail: clientInfo.userEmail
      }
    )
    await clientManager.broadcastToUser(email, event)
  }
}

/**
 * Handle CALL_MEDIA_STATE message
 * Relay media state changes (mute, camera on/off) to other participants
 */
export async function handleCallMediaState(ws, clientInfo, message, clientManager, eventStore) {
  const { callId, audio, video, screenShare } = message
  const call = activeCalls.get(callId)
  
  if (!call) return
  
  for (const participantEmail of call.participants) {
    if (participantEmail === clientInfo.userEmail) continue
    
    const event = await eventStore.createEvent(
      EventTypes.CALL_MEDIA_STATE,
      participantEmail,
      {
        callId,
        participantEmail: clientInfo.userEmail,
        audio,
        video,
        screenShare
      }
    )
    await clientManager.broadcastToUser(participantEmail, event)
  }
}

/**
 * Handle CALL_SCREEN_SHARE_START/STOP
 */
export async function handleCallScreenShare(ws, clientInfo, message, clientManager, eventStore, isStart) {
  const { callId } = message
  const call = activeCalls.get(callId)
  
  if (!call) return
  
  const eventType = isStart ? EventTypes.CALL_SCREEN_SHARE_START : EventTypes.CALL_SCREEN_SHARE_STOP
  
  for (const participantEmail of call.participants) {
    if (participantEmail === clientInfo.userEmail) continue
    
    const event = await eventStore.createEvent(
      eventType,
      participantEmail,
      {
        callId,
        participantEmail: clientInfo.userEmail
      }
    )
    await clientManager.broadcastToUser(participantEmail, event)
  }
}

/**
 * Handle call timeout (no answer)
 */
async function handleCallTimeout(callId, clientManager, eventStore, pushService = null) {
  const call = activeCalls.get(callId)
  if (!call) return
  
  console.log(`[CallSignaling] Call timed out: ${callId}`)
  
  // Send CALL_MISSED to caller (they see "No answer")
  const callerEvent = await eventStore.createEvent(
    EventTypes.CALL_MISSED,
    call.initiatedBy,
    {
      callId,
      conversationId: call.conversationId,
      callType: call.callType,
      participants: call.participants
    }
  )
  await clientManager.broadcastToUser(call.initiatedBy, callerEvent)
  
  // Send CALL_MISSED to callees (they see "Missed call from X")
  const callerName = call.initiatedBy.split('@')[0]
  for (const participantEmail of call.participants) {
    if (participantEmail === call.initiatedBy) continue
    
    const event = await eventStore.createEvent(
      EventTypes.CALL_MISSED,
      participantEmail,
      {
        callId,
        conversationId: call.conversationId,
        callType: call.callType,
        callerEmail: call.initiatedBy,
        callerName
      }
    )
    const delivered = await clientManager.broadcastToUser(participantEmail, event)
    
    // Send push notification if user wasn't connected
    if (delivered === 0 && pushService) {
      pushService.sendPushDirectly(participantEmail, {
        type: 'CALL_MISSED',
        payload: {
          callId,
          conversationId: call.conversationId,
          callType: call.callType,
          callerEmail: call.initiatedBy,
          callerName
        }
      }).catch(err => {
        console.error(`[CallSignaling] Push notification error for ${participantEmail}:`, err.message)
      })
    }
  }
  
  activeCalls.delete(callId)
  callTimers.delete(callId)
}

/**
 * Get active call for a conversation (if any)
 */
export function getActiveCall(conversationId) {
  for (const [callId, call] of activeCalls) {
    if (call.conversationId === conversationId) {
      return { callId, ...call }
    }
  }
  return null
}

/**
 * Clean up all active calls (for shutdown)
 */
export function cleanupAllCalls() {
  for (const [, timer] of callTimers) {
    clearTimeout(timer)
  }
  callTimers.clear()
  activeCalls.clear()
  console.log('[CallSignaling] All active calls cleaned up')
}

