/**
 * Mail Sync Server Configuration
 * 
 * Loads configuration from environment variables with sensible defaults.
 */

import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// Load .env file
dotenv.config({ path: path.join(__dirname, '..', '.env') })

export const config = {
  // WebSocket server
  ws: {
    host: process.env.MAILSYNC_WS_HOST || '0.0.0.0',
    port: parseInt(process.env.MAILSYNC_WS_PORT || '1235', 10),
  },

  // SSL for direct WebSocket (bypassing reverse proxy)
  ssl: {
    enabled: process.env.MAILSYNC_SSL_ENABLED === 'true',
    keyPath: process.env.MAILSYNC_SSL_KEY || '/etc/letsencrypt/live/email.devcon1.hu/privkey.pem',
    certPath: process.env.MAILSYNC_SSL_CERT || '/etc/letsencrypt/live/email.devcon1.hu/fullchain.pem',
  },

  // JWT (must match PHP backend)
  jwt: {
    secret: process.env.JWT_SECRET || '',
    algorithm: process.env.JWT_ALGORITHM || 'HS256',
  },

  // IMAP settings
  imap: {
    host: process.env.IMAP_HOST || 'localhost',
    port: parseInt(process.env.IMAP_PORT || '993', 10),
    tls: process.env.IMAP_TLS !== 'false',
    tlsOptions: {
      rejectUnauthorized: process.env.IMAP_VERIFY_CERT === 'true',
    },
    // IDLE timeout (RFC 2177 recommends 29 minutes max)
    idleTimeout: parseInt(process.env.IMAP_IDLE_TIMEOUT || '1680000', 10), // 28 minutes
    // Reconnection settings
    reconnectDelay: parseInt(process.env.IMAP_RECONNECT_DELAY || '5000', 10),
    maxReconnectAttempts: parseInt(process.env.IMAP_MAX_RECONNECT_ATTEMPTS || '10', 10),
  },

  // Redis
  redis: {
    host: process.env.REDIS_HOST || '127.0.0.1',
    port: parseInt(process.env.REDIS_PORT || '6379', 10),
    password: process.env.REDIS_PASSWORD || null,
    database: parseInt(process.env.REDIS_DATABASE || '0', 10),
    prefix: 'webmail:',
    // Event store settings
    eventBufferSize: parseInt(process.env.EVENT_BUFFER_SIZE || '100', 10),
    eventBufferTtl: parseInt(process.env.EVENT_BUFFER_TTL || '300', 10), // 5 minutes
  },

  // Web Push (VAPID credentials)
  // Generate keys with: node ../../scripts/generate-vapid-keys.js
  push: {
    vapidPublicKey: process.env.VAPID_PUBLIC_KEY || '',
    vapidPrivateKey: process.env.VAPID_PRIVATE_KEY || '',
    vapidSubject: process.env.VAPID_SUBJECT || 'mailto:admin@devcon1.hu',
  },

  // Logging
  logLevel: process.env.LOG_LEVEL || 'info',

  // Performance tuning
  performance: {
    // Max IDLE connections per server instance
    maxIdleConnections: parseInt(process.env.MAX_IDLE_CONNECTIONS || '500', 10),
    // Heartbeat interval for WebSocket clients
    heartbeatInterval: parseInt(process.env.WS_HEARTBEAT_INTERVAL || '30000', 10),
    // Client timeout (no heartbeat)
    clientTimeout: parseInt(process.env.WS_CLIENT_TIMEOUT || '60000', 10),
  },
}

